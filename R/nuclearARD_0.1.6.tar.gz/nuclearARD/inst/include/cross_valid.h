#ifndef NUCLEARARD_CROSS_VALID_H
#define NUCLEARARD_CROSS_VALID_H

#include <RcppArmadillo.h>
#include "Ji_Ye_eqs.h"
#include "matrix_regression.h"
#include "matrix_functions.h"
#include <algorithm>    // for std::shuffle and std::fill
#include <random>  

double cross_validation(const arma::mat& inputs,
                                   const arma::mat& outputs,
                                   const SEXP& lambda_sexp,
                                   const std::string& Lipschitz = "regression",
                                   const int iterations = 5000,
                                   const double etol = 1e-5,
                                   const double gamma = 2.0,
                                   const bool symmetrize = true,
                                   const bool fixed_effects = false,
                                   const Rcpp::NumericVector& CV_grid = Rcpp::NumericVector(), 
                                   const int CV_folds = 5);

#endif 
