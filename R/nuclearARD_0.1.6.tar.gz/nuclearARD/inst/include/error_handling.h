#ifndef NUCLEARARD_ERROR_H
#define NUCLEARARD_ERROR_H

#include <RcppArmadillo.h>

bool obj_func_testing(arma::mat inputs, arma::mat outputs, arma::mat W_k);


#endif
